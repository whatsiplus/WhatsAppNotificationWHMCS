<p align="center">*********************************************************************************************************************************************/<br>
<br>
Whatsiplus Notification 7.1.5 by Whatsiplus
 <br>
Copyright WHMCS Services, All Rights Reserved<br>
Created By WHMCSServices <a href="https://whatsiplus.com">whatsiplus.com</a>
<br>
This software is furnished under a license and may be used and copied
 only  in  accordance  with  the  terms  of such  license and with the&nbsp; inclusion of the above copyright notice.
<br>
This software  or any other&nbsp; copies thereof may not be provided or otherwise made available to any&nbsp; other person.  No title to and  ownership of the  software is  hereby&nbsp; transferred.</p>
<p align="center">
********************************************************************************************************************************************/</p>




