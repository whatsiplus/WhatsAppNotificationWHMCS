<?php
/*
 * @ https://whatsiplus.com
 */
echo "<p align=\"center\"><b>Whatsiplus Notification</b></p>";

?>